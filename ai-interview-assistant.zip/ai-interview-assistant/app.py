# =====================================================================
# AI Interview Preparation Assistant - Flask Backend
# =====================================================================
# A Flask web application that generates AI-powered interview questions
# with detailed answers in bullet-point format.
# =====================================================================

# Import necessary libraries
from flask import Flask, render_template, request, jsonify
import requests
import json

# =====================================================================
# FLASK APP INITIALIZATION
# =====================================================================
app = Flask(__name__, template_folder='templates')

# =====================================================================
# ROUTE: Home Page (http://localhost:5000/)
# =====================================================================
@app.route('/')
def home():
    """
    Renders the main homepage with input form.
    """
    return render_template('index.html')

# =====================================================================
# ROUTE: Generate Questions API (http://localhost:5000/generate)
# =====================================================================
@app.route('/generate', methods=['POST'])
def generate_questions():
    """
    Receives job role and skills, generates questions with answers.
    """
    try:
        # Get JSON data from the frontend
        data = request.get_json()
        
        # Extract job role and skills
        job_role = data.get('job_role', '')
        skills = data.get('skills', '')
        
        # Validate input
        if not job_role or not skills:
            return jsonify({
                "error": "Please enter both job role and skills!"
            }), 400
        
        # Try AI service, use template as fallback
        try:
            questions_data = call_ai_service(job_role, skills)
        except Exception as ai_error:
            print(f"AI service unavailable: {ai_error}")
            questions_data = generate_detailed_template(job_role, skills)
        
        return jsonify(questions_data)
        
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            "error": "Something went wrong! Please try again."
        }), 500

# =====================================================================
# FUNCTION: Call AI Service
# =====================================================================
def call_ai_service(job_role, skills):
    """
    Calls Ollama AI to generate questions with bullet-point format.
    """
    prompt = f"""Generate interview preparation for {job_role} role with skills: {skills}

STRICT FORMAT - Use this exact format:

{{
    "technical_questions": [
        {{
            "question": "Question text here?",
            "answer": ["Point 1", "Point 2", "Point 3", "Point 4"],
            "explanation": ["Point 1", "Point 2"]
        }},
        (repeat for 5 questions)
    ],
    "hr_questions": [
        {{
            "question": "HR question here?",
            "sample_answer": ["Point 1", "Point 2", "Point 3"]
        }},
        (repeat for 3 questions)
    ],
    "preparation_tips": ["Tip 1", "Tip 2", "Tip 3", "Tip 4", "Tip 5"]
}}

Use bullet-point format in arrays as shown above."""

    try:
        response = requests.post(
            'http://localhost:11434/api/generate',
            json={
                "model": "llama2",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.7,
                    "max_tokens": 2000
                }
            },
            timeout=60
        )
        
        if response.status_code == 200:
            ai_response = response.json()
            try:
                generated_text = ai_response.get('response', '')
                questions_data = json.loads(generated_text)
                return questions_data
            except json.JSONDecodeError:
                raise Exception("Invalid JSON from AI")
        else:
            raise Exception(f"Ollama error: {response.status_code}")
            
    except requests.exceptions.ConnectionError:
        raise Exception("Cannot connect to Ollama")
    except Exception as e:
        raise Exception(f"AI Error: {str(e)}")

# =====================================================================
# FUNCTION: Generate Template with Bullet Points
# =====================================================================
def generate_detailed_template(job_role, skills):
    """
    Generates questions with bullet-point format (answers as arrays).
    """
    # Split skills
    skill_list = [s.strip() for s in skills.split(',')]
    primary_skill = skill_list[0] if skill_list else "this technology"
    all_skills = ", ".join(skill_list) if skill_list else "relevant skills"
    
    # Technical Questions with bullet-point answers
    technical_questions = [
        {
            "question": f"Explain the difference between {primary_skill} and related technologies. When would you choose one over the other?",
            "answer": [
                f"{primary_skill} is specific while alternatives serve different purposes",
                "Choose based on performance requirements",
                "Consider project complexity and team expertise",
                "Check community support and documentation"
            ],
            "explanation": [
                "Tests understanding of technology landscape",
                "Shows ability to make informed technical decisions",
                "Employers want to see you understand trade-offs"
            ]
        },
        {
            "question": f"How would you handle a situation where {primary_skill} is not working in production?",
            "answer": [
                "Check error logs and monitoring systems immediately",
                "Isolate the issue by reproducing in development",
                "Review recent changes to the codebase",
                "Implement fix and test before deploying"
            ],
            "explanation": [
                "Assesses problem-solving under pressure",
                "Companies need developers who troubleshoot effectively",
                "Shows your systematic approach"
            ]
        },
        {
            "question": f"Describe a challenging project where you used {all_skills}. What challenges did you face?",
            "answer": [
                "Broke project into smaller tasks",
                "Wrote clean modular code",
                "Implemented comprehensive testing",
                "Followed agile methodologies"
            ],
            "explanation": [
                "Reveals practical experience",
                "Shows real-world problem-solving",
                "Demonstrates teamwork skills"
            ]
        },
        {
            "question": f"What are the best practices for {primary_skill} development?",
            "answer": [
                "Write clean, readable code with proper comments",
                "Follow coding standards and conventions",
                "Implement comprehensive tests",
                "Use version control and code reviews"
            ],
            "explanation": [
                "Verifies software engineering best practices",
                "Quality code is crucial for maintainability",
                "Important for team collaboration"
            ]
        },
        {
            "question": f"How do you stay updated with latest developments in {primary_skill}?",
            "answer": [
                "Follow official documentation and release notes",
                "Read tech blogs and articles",
                "Take online courses and certifications",
                "Experiment with new technologies"
            ],
            "explanation": [
                "Shows commitment to continuous learning",
                "Technology evolves rapidly",
                "Need developers who stay current"
            ]
        }
    ]
    
    # HR Questions with bullet-point answers
    hr_questions = [
        {
            "question": "Tell me about yourself and why you're interested in this role?",
            "sample_answer": [
                f"I have experience in {all_skills}",
                "I'm passionate about building scalable solutions",
                f"My technical skills fit this role well",
                "I'm excited about this opportunity"
            ]
        },
        {
            "question": "What are your greatest strengths and weaknesses?",
            "sample_answer": [
                "My strengths are technical skills and quick learning",
                "I've improved my time management",
                "I'm working on public speaking",
                "I welcome feedback and growth"
            ]
        },
        {
            "question": "Where do you see yourself in 5 years?",
            "sample_answer": [
                "See myself as a senior developer or tech lead",
                "Want to grow technical expertise",
                "Plan to mentor junior developers",
                "Want to lead technical initiatives"
            ]
        }
    ]
    
    # Preparation Tips
    preparation_tips = [
        "Research the company thoroughly before the interview",
        "Practice answering questions out loud",
        "Prepare your own questions to ask the interviewer",
        "Review your projects and be ready to discuss them",
        "Get adequate rest before the interview"
    ]
    
    return {
        "technical_questions": technical_questions,
        "hr_questions": hr_questions,
        "preparation_tips": preparation_tips
    }

# =====================================================================
# MAIN: Run the Flask App
# =====================================================================
if __name__ == '__main__':
    print("=" * 60)
    print("🎯 AI Interview Preparation Assistant")
    print("=" * 60)
    print("Starting server at: http://localhost:5000")
    print("Press Ctrl+C to stop the server")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
