# 🎯 AI Interview Preparation Assistant

A modern Flask web application that uses Generative AI to help users prepare for job interviews by generating **technical questions with detailed answers and explanations**, **HR questions with sample answers**, and **preparation tips**.

## 📁 Project Structure

```
ai-interview-assistant/
├── app.py                  # Flask backend (main application)
├── requirements.txt        # Python dependencies
├── README.md              # This file
├── templates/
│   └── index.html         # Frontend HTML
└── static/
    └── style.css         # Custom styling
```

## 🎯 What This Project Generates

### A. Technical Interview Questions WITH Answers (5)
Each technical question includes:
- **Question**: The interview question
- **Answer**: Detailed step-by-step answer
- **Explanation**: Why this question is important

### B. HR Interview Questions WITH Sample Answers (3)
Each HR question includes:
- **Question**: Behavioral question
- **Sample Answer**: Professional response

### C. Interview Preparation Tips (5)
- Actionable tips to help you prepare

## 📖 Installation Steps

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Step 1: Navigate to Project Directory
```bash
cd C:\Users\abhij\Desktop\ai-interview-assistant
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

Or install individually:
```bash
pip install flask requests
```

## 🎮 How to Run

### Option 1: Basic Run (Using Template-Based Questions)
```bash
python app.py
```
Then open your browser to: http://localhost:5000

### Option 2: Run with AI (Using Ollama)
Ollama is a free, locally-running AI model. This provides better, more personalized questions with answers.

1. Download Ollama from: https://ollama.com
2. Install and start Ollama:
   ```bash
   ollama serve
   ```
3. In another terminal, run the Flask app:
   ```bash
   python app.py
   ```

## 📖 How to Use

1. **Open the Application**
   - Go to http://localhost:5000 in your web browser

2. **Enter Job Details**
   - Fill in the Job Role (e.g., "Python Developer", "Data Scientist")
   - Enter your Skills (e.g., "Python, Django, SQL, JavaScript")

3. **Generate Questions**
   - Click the "Generate Interview Preparation" button

4. **View Results**
   Each result includes:
   - **Technical Question**: Question → Answer → Explanation
   - **HR Question**: Question → Sample Answer
   - **Preparation Tips**: Actionable advice

## 🎓 Perfect for College Projects

This project is designed to be:
- ✅ **Beginner-friendly** - Well-commented code for learning
- ✅ **Easy to explain** - Clean structure for presentations
- ✅ **Modern UI** - Impressive for demonstrations
- ✅ **Expandable** - Easy to add more features
- ✅ **AI-Powered** - Uses real AI for generating answers

### Suggested Presentation Points:
1. How Flask handles web requests
2. API design with JSON
3. Frontend-backend communication with fetch API
4. Responsive design with CSS
5. How AI generates content
6. Future improvements you could add

## 🔧 Troubleshooting

### Port Already in Use
If port 5000 is busy, modify the port in app.py:
```python
app.run(debug=True, port=5001)
```

### Ollama Not Connecting
- Make sure Ollama is running: `ollama serve`
- The app will automatically use template-based questions as fallback

### Dependencies Error
- Make sure you're in the project directory
- Try: `pip install --upgrade flask requests`

## 📝 Example Output Format

### Technical Question 1:
**Question:** Explain the difference between Python list and tuple? When would you choose one over the other?

**Answer:** 
- Lists are mutable (can be changed) while tuples are immutable (cannot be changed)
- Tuples use less memory and are faster than lists
- Use lists when you need to modify data, tuples for fixed data

**Explanation:**
This tests your understanding of Python data structures. Employers want to see you understand not just how to use these structures, but when to use each.

### HR Question 1:
**Question:** Tell me about yourself and why you're interested in this role?

**Sample Answer:**
I am a dedicated professional with experience in Python, Django, and SQL. I'm passionate about building scalable solutions... [continues]

---

Made with ❤️ for helping students ace their interviews
